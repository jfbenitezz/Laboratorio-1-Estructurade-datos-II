/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BinarySearchTree;

import java.util.LinkedList;
import java.util.Queue;

/**
 *
 * @author rcarrieta
 */
public class AVLTree {

    Node root;

    //Subrutina para facilitar el equilibrio del arbol.
    public void Agregar(int data) {
        if (this.root == null) {
            this.root = new Node(data);
        } else {
            //Se agrega el nodo y se equilibra el arbol de ser necesario.
            this.AgregarNode(root, data);
            boolean sw = this.NcBalance(root, data);
            while (sw == true) {
                this.Rebalancear(root, data);
                sw = this.NcBalance(root, data);
            }

        }
    }

    // Recorre el arbol segun el valor dado.
    private void AgregarNode(Node v, int data) {
        boolean sw = true;
        while (sw == true) {
            if (data == v.X) {
                sw = false;
            } else {
                //Se evalua el valor y se mueve en la direccion correspondiente hasta agregarlo.
                if (data < v.X) {
                    if (v.left == null) {
                        v.left = new Node(data);
                        sw = false;
                    } else {
                        v = v.left;
                    }
                } else {
                    if (v.right == null) {
                        v.right = new Node(data);
                        sw = false;
                    } else {
                        v = v.right;
                    }
                }
            }
        }

    }
    
    //Busqueda de nodo por niveles, devuelve valor determinado.
    public Node BuscarNode(Node v, int data) { 
        Queue<Node> queue = new LinkedList<Node>();
        if (v == null) {
            return null;
        }
        queue.add(v);
        while (queue.isEmpty() == false) {
            Node aux = queue.poll();
            //Se comprueba si el nodo y el valor coniciden, caso contrario se sigue buscando.
            if (data == aux.X) { 
                return aux;
            }
            if (aux.right != null && data > aux.X) {
                queue.add(aux.right);
            }
            if (aux.left != null && data < aux.X) {
                queue.add(aux.left);
            }
        }
        return null; 
    }

    //Subrutina para facilitar el equilibrio del arbol.
    public void Eliminar(int data) {
        if (this.root == null) {
            //Arbol vacio.
        } else {
            if (data == this.root.X && this.root.left == null && this.root.right == null) {
                this.root = null;
            } else {
                //Se elimina el nodo y se equilibra el arbol de ser necesario.
                this.EliminarNode(root, data);
                boolean sw = this.NcBalance(root, data);
                while (sw == true) {
                    this.Rebalancear(root, data);
                    sw = this.NcBalance(root, data);
                }
            }
        }
    }

    private void EliminarNode(Node v, int data) {
        boolean sw = true;
        Node aux = v;
        while (sw == true) {
            //Se recorre el arbol hasta encontrar el valor o no.
            if (aux == null) {
                sw = false;
            } else {
                if (aux.X == data) {
                    //Se detienen las iteraciones y se elimina el nodo.
                    sw = false;
                    Eliminacion(aux);
                } else if (aux.X > data) {
                    aux = aux.left;
                } else {
                    aux = aux.right;
                }
            }
        }

    }

    //Subrutina para eliminar el nodo.
    private void Eliminacion(Node v) {
        Node aux = v;
        boolean sw = false;
        //Al saber que hay un nodo valido, se atraviesa el arbol hasta llegar al fondo.
        while (sw == false) {
            //Se detiene una vez encontrado el valor  ya haber llegado al ultimo novel.
            if (aux.right == null && aux.left == null) {
                sw = true;
            } else {
                //En caso de ser la raiz, debe tener al menos un hijo.
                if (aux == this.root) {
                    //Debido a esto, se comprueba si uno de los subárboles está vacío y si es cierto, se va al subárbol no vacío de la raíz.
                    if (aux.left == null) {
                        aux = aux.right;
                    } else if (aux.right == null) {
                        aux = aux.left;
                    } else {
                        //Si podemos elegir entre subárboles (ninguno está vacío), atravesamos el subárbol con la altura más baja para minimizar las iteraciones.
                        if (this.Altura(aux.left) <= this.Altura(aux.right)) {
                            aux = aux.left;
                        } else if (this.Altura(aux.right) < this.Altura(aux.left)) {
                            aux = aux.right;
                        }
                    }
                } else {
                    //Si es el subarbol derecho, se busca el valor mas a la izquierda.
                    if (aux.X > this.root.X) {
                        if (aux.left == null && aux.right != null) {
                            /**
                             * En el caso específico que no se pueda acceder
                             * fácilmente al valor más bajo del subárbol derecho
                             * porque tiene un hijo, se intercambia ese valor
                             * con el del hijo.
                             */
                            if (aux.right.left == null && aux.right.right == null) {
                                int temp = aux.X;
                                aux.X = aux.right.X;
                                aux.right.X = temp;
                            }

                            aux = aux.right;
                        } else {
                            if (aux.left != null) {
                                aux = aux.left;
                            }
                        }
                    } else {
                        //Caso contrario.
                        if (aux.right == null && aux.left != null) {
                            if (aux.left.left == null && aux.left.right == null) {
                                int temp = aux.X;
                                aux.X = aux.left.X;
                                aux.left.X = temp;
                            }
                            aux = aux.left;
                        } else {
                            if (aux.right != null) {
                                aux = aux.right;
                            }
                        }
                    }
                }
            }
        }

        int nval = aux.X;
        //Se almacena el valor del nodo en la parte inferior del arbol, se busca su padre, y se elimina el nodo.
        if (BuscarPadres(this.root, nval).right == aux) {
            BuscarPadres(this.root, nval).right = null;
        } else {
            BuscarPadres(this.root, nval).left = null;
        }
        v.X = nval;
        /**
         * Al final, se asigna el nodo con el valor dado que se almaceno
         * anteriormente. Asi, en lugar de eliminar el nodo con el valor dado,
         * se intercambia el valor con el de un nodo en la parte inferior del
         * árbol y se elimina ese nodo por simplicidad. Por consecuente, se
         * busca el valor más bajo del subárbol derecho, o el valor más alto del
         * subárbol izquierdo. De esa manera mantenemos el equilibrio numérico.
         */
    }
    
    // Subrutina para usuario, toma la pisoblidad de un arbol vacio.
    public Node Abuelo(int data) { 
        if (this.root == null) {
            return null;
        } else {
            //Evalua el nodo para ver si tiene un abuelo y lo retorna o no.
            if (BuscarAbuelo(this.root, data) == null) { 
                return null;
            } else {
                return this.BuscarAbuelo(this.root, data);
            }
        }
    }
    
    //Busqueda de nivel simple.
    private Node BuscarAbuelo(Node v, int data) { 
        Queue<Node> queue = new LinkedList<Node>();
        queue.add(v);
        while (queue.isEmpty() == false) {
            Node aux = queue.poll();
            /**Se miran los nodos hijos para comprobar si existen, si lo hacen, se comprueba si tienen hijos y si también lo tienen, 
             se verifica si el valor del nodo nieto es el mismo que el valor dado.*/
            if (aux.right != null && data > aux.X) { 
                if ((aux.right.left != null && aux.right.left.X == data) || (aux.right.right != null && aux.right.right.X == data)) {
                    return aux; 
                }
                queue.add(aux.right);
            }
            if (aux.left != null && data < aux.X) {
                if ((aux.left.left != null && aux.left.left.X == data) || (aux.left.right != null && aux.left.right.X == data)) {
                    return aux;
                }
                queue.add(aux.left);
            }
        }
        return null; 
    }
    
    // Subrutina para usuario, toma la pisoblidad de un arbol vacio.
    public Node Tio(int data) { 
        if (this.root == null) {
            return null;
        } else {
            //Evalua el nodo para ver si tiene un tio y lo retorna o no.
            if (BuscarTio(this.root, data) == null) { 
                return null;
            } else {
                return this.BuscarTio(this.root, data);
            }
        }
    }

    //Busqueda de nivel simple.
    private Node BuscarTio(Node v, int data) { 
        Queue<Node> queue = new LinkedList<Node>();
        queue.add(v);
        while (queue.isEmpty() == false) {
            Node aux = queue.poll();
            /** Misma idea de la subrutina BuscarAbuelo.
             * Sin embargo, en lugar de devolver el nodo abuelo, se devuelve el nodo tío (si existe).
               Esencialmente, se devuelve el hijo izquierdo si el nodo nieto está en el subárbol derecho y viceversa.*/
            if (aux.right != null && data > aux.X) { 
                if ((aux.right.left != null && aux.right.left.X == data) || (aux.right.right != null && aux.right.right.X == data)) {
                    return aux.left; 
                }
                queue.add(aux.right);
            }
            if (aux.left != null && data < aux.X) {
                if ((aux.left.left != null && aux.left.left.X == data) || (aux.left.right != null && aux.left.right.X == data)) {
                    return aux.right;
                }
                queue.add(aux.left);
            }
        }
        return null; 
    }
    //Busqueda para encontrar el nivel de un nodo, se usa una variable para ver cuntas veces se baja, se asume que el arbol no esta vacio.
    public int NivelNode(Node v) {  
        int lvl = 0; 
        Queue<Node> queue = new LinkedList<Node>();
        queue.add(this.root);
        while (queue.isEmpty() == false) {
            Node aux = queue.poll();
            //Se devuelve el contador al encontrar el nodo.
            if (aux == v) {
                return lvl;
            }
            //Se utilizan propiedades del arbol.
            if (aux.right != null && v.X > aux.X) {
                queue.add(aux.right);
            }
            if (aux.left != null && v.X < aux.X) {
                queue.add(aux.left);
            }
            //Se baja independientemente de la direccion.
            lvl++; 
        }
        return lvl;
    }
    
    public void Recorrido(Node v, int level) {
        if (v == null) { 
            System.out.println("El árbol está vacío");
            return;
        } else {
            //Se detiene una vez impreso todo el arbol.
            if (level > this.Altura(this.root)) { 
                return;
            } else {
                //Se imprime por niveles.
                System.out.println("\n");
                this.RecorridoRecursivo(root, level);
            }
        }
        //Se llama de nuevo la subrutina para el siguiente nivel.
        Recorrido(v, level + 1); 
    }

    //Busqueda recurrsiva por niveles.
    private void RecorridoRecursivo(Node v, int lv) { 
        LinkedList<Integer> rec = new LinkedList<Integer>();
        if (v == null) { 
            return;
        } else { 
            //Esta subrutina imprime los nodos de un nivel X.
            if (lv == 0) { 
                System.out.print(v.X+" ");
                rec.add(v.X);
            } else if (lv > 0) {
                /**Se llama a sí mismo pero con los hijos a buscar todos los nodos con el nivel dado en el árbol.
                 * lv, actúa como una contravariable, cada vez que nos acercamos al hijo,
                  se disminuye la distancia en niveles entre el nodo actual y el buscando.*/
                RecorridoRecursivo(v.left, lv - 1); 
                RecorridoRecursivo(v.right, lv - 1);
            }
        }
    }
    
    /**Busqueda de nivel con propiedades de los arboles. Con cada iteración, se  comprueba buscar el nodo con un hijo con el valor dado y se devuelve.
       Se asume que exite el nodo a buscar porque el nodo hijo existe y el nodo que se va a eliminar no es la raíz.*/
    public Node BuscarPadres(Node v, int data) { 
        Queue<Node> queue = new LinkedList<Node>(); 
        queue.add(v);
        while (queue.isEmpty() == false) {
            Node aux = queue.poll();
            if (aux.left != null) {
                //Se comprueba si el nodo actual tienen un hiijo, y si es el del valor dado.
                if (aux.left.X == data) { 
                    return aux;
                }
            }
            if (aux.right != null) {
                if (aux.right.X == data) {
                    return aux;
                }
            }
            if (aux.right != null && data > aux.X) {
                queue.add(aux.right);
            }
            if (aux.left != null && data < aux.X) {
                queue.add(aux.left);
            }
        }
        return null;
    }
    
    /**Se busca altura de los nodos, se toma la raiz como argumento para obtener la altura del arbol.
       En caso de estar vacio se retorna -1 y se compensa despues.*/ 
    private int Altura(Node v) { 
        if (v == null) {
            return -1; 
        } else {
            //Se calcula en ambas direcciones y se toma el valor mas alto.
            int l = Altura(v.left); 
            int r = Altura(v.right);
            if (l > r) {
                return l + 1;  
            } else {
                return r + 1;
            }
        }
    }
    
    //Para tulizar en el JFrame
    public int ObtAltura(Node v) { 
        return Altura(v);
    }
    
    //Se comparan las alturas de los subArboles para buscar el factor de equilibrio.
    private int FactorEq(Node v) {
        return Altura(v.right) - Altura(v.left); 
    }

    //Rotaciones simples.     
    private Node RotacionDer(Node v) {
        Node son = v.right;
        v.right = son.left;
        son.left = v;
        return son;
    }

    private Node RotacionIzq(Node v) { 
        Node son = v.left;
        v.left = son.right;
        son.right = v;
        return son;
    }
    
    //Se equilibra un nodo dado.
    private Node Balancear(Node v) {
        //Se comprueba si el nodo necesita equilibrarse o no. Y de que lado esta el desequilibrio.
        if (this.FactorEq(v) == 2) { 
            //Despues de tener la dirrecion, evaluamos el tipo de rotacion que necesita.
            if (Altura(v.right.right) > Altura(v.right.left)) { 
                v = RotacionDer(v);
            } else {
                v.right = RotacionIzq(v.right);
                v = RotacionDer(v);
            }
        } else if (this.FactorEq(v) == -2) {
            if (Altura(v.left.left) > Altura(v.left.right)) {
                v = RotacionIzq(v);
            } else {
                v.left = RotacionDer(v.left);
                v = RotacionIzq(v);
            }
        }
        return v;
    }

    //Se busca un desequilibrio utilizando el FE, si un nodo necesita equilibrio entonces el arbol tambien.
    private boolean NcBalance(Node v, int data) { 
        Queue<Node> queue = new LinkedList<Node>();
        queue.add(v);
        while (queue.isEmpty() == false) {
            Node aux = queue.poll();
            //Se comprueba el FE y se devuelve si el arbol necesita o no equilibrarse.
            if (this.FactorEq(aux) > 1 || this.FactorEq(aux) < -1) { 
                return true;
            }
            //Se utilizan las propiedades del árbol para comprobar solo el subárbol modificado.
            if (aux.right != null && data > aux.X) { 
                queue.add(aux.right);
            }
            if (aux.left != null && data < aux.X) {
                queue.add(aux.left);
            }
        }
        return false;
    }

    //Se equilibra de abajo hacia arriba, con el uso de la siguiente subrutina.
    private void Rebalancear(Node v, int data) { 
        for (int level = this.Altura(this.root); level >= 1; level--) {
            this.RecorridoRecursivoRB(root, level, data);
        }
        this.root = this.Balancear(this.root);

    }

    //Recorrido de nivel recursivo. Explicada en RecorridoRecursivo.
    private void RecorridoRecursivoRB(Node v, int lv, int data) {  
        if (v == null) {
            return; 
        } else {
            if (v.X > data) {
                if (lv - 1 == 0) {
                    if (v.left != null) {
                        v.left = this.Balancear(v.left);
                    }
                } else {
                    RecorridoRecursivoRB(v.left, lv - 1, data);
                }

            } else {
                if (lv - 1 == 0) {
                    if (v.right != null) {
                        v.right = this.Balancear(v.right);
                    }
                } else {
                    RecorridoRecursivoRB(v.right, lv - 1, data);
                }

            }
        }
    }

}
