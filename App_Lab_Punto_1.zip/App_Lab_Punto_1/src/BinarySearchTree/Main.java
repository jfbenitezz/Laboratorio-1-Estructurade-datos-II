/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BinarySearchTree;

/**
 *
 * @author rcarrieta
 */
public class Main {
    public static void main(String[] args) {
        AVLTree tree = new AVLTree();
        Windows Img = new Windows(tree);
        Img.setSize(1200, 900);
        Img.setResizable(false);
        Img.setVisible(true);
    }
}
